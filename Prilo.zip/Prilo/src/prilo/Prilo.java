package prilo;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import javax.imageio.ImageIO;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.WindowConstants;
public class Prilo extends JFrame {
private static Prilo Prilo;
private static long last_frame_time;
private static Image logo;
private static Image fon;
private static float drop_left = 20;
private static float drop_top = -100;
private static float drop_v = 200;
private static int score = 0;

public static void main(String[] args) throws IOException {
fon = ImageIO.read(Prilo.class.getResourceAsStream("fon.jpg"));
logo = ImageIO.read(Prilo.class.getResourceAsStream("logo.jpg"));
Prilo = new Prilo();
Prilo.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
Prilo.setLocation(200,50);
Prilo.setSize(1350,790);
Prilo.setResizable(false);
last_frame_time = System.nanoTime();
GameField game_field = new GameField();
game_field.addMouseListener(new MouseAdapter() {
@Override
public void mousePressed(MouseEvent e){
int x = e.getX();
int y = e.getY();
float drop_right = drop_left + end.getWidth(null);
float drop_bottom = drop_top + end.getHigth(null);
boolean is_drop=x>=drop_left&&x<= drop_right&& y >= drop_top && y <= drop_bottom;

if(is_drop) {
drop_top = -100;
drop_left = (int) (Math.random() * (game_field.getWidth() - end.getWidth(null)));
drop_v = drop_v +10;
score++;
Prilo.setTitle("Score:" + score);
}
}
});
Prilo.add(game_field);
Prilo.setVisible(true);
}
private static void onRepaint(Graphics g){
long current_time = System.nanoTime();
float delt_time = (current_time - last_frame_time) * 0.000000001f;
last_frame_time = current_time;
drop_top=drop_top+drop_v*delt_time;
g.drawImage(fon, 0, 0, null);
g.drawImage(logo, (int) drop_left, (int) drop_top, null);
if(drop_top > Prilo.getHeight()) g.drawImage(logo, 20, 50, null);
}
private static class GameField extends JPanel{
@Override
protected void paintComponent (Graphics g){
super.paintComponent(g);
onRepaint(g);
repaint();
}
}
}
