
public class d408 {

	public static void main(String[] args) {
		System.out.println("Мешковский Олег ДКИП-408");
		System.out.println("М ");
		System.out.println("е ");
		System.out.println("ш ");
		System.out.println("к ");
		System.out.println("о ");
		System.out.println("в ");
		System.out.println("с ");
		System.out.println("к ");
		System.out.println("и ");
		System.out.println("й ");
		int age = 19;
		System.out.println("Мешковский "+ age );
		
		

	}
}
