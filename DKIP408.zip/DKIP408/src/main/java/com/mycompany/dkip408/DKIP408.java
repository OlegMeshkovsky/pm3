/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.dkip408;

/**
 *
 * @author oleg1
 */
public class DKIP408 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
